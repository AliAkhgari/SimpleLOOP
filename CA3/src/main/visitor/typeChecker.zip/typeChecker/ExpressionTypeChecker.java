package main.visitor.typeChecker;

import main.ast.nodes.declaration.classDec.ClassDeclaration;
import main.ast.nodes.declaration.classDec.classMembersDec.MethodDeclaration;
import main.ast.nodes.expression.*;
import main.ast.nodes.expression.operators.BinaryOperator;
import main.ast.nodes.expression.operators.TernaryOperator;
import main.ast.nodes.expression.operators.UnaryOperator;
import main.ast.nodes.expression.values.NullValue;
import main.ast.nodes.expression.values.SetValue;
import main.ast.nodes.expression.values.primitive.BoolValue;
import main.ast.nodes.expression.values.primitive.IntValue;
import main.ast.types.NoType;
import main.ast.types.NullType;
import main.ast.types.Type;
import main.ast.types.array.ArrayType;
import main.ast.types.functionPointer.FptrType;
import main.ast.types.primitives.BoolType;
import main.ast.types.primitives.ClassType;
import main.ast.types.primitives.IntType;
import main.ast.types.set.SetType;
import main.compileError.typeError.*;
import main.symbolTable.SymbolTable;
import main.symbolTable.exceptions.ItemNotFoundException;
import main.symbolTable.items.ClassSymbolTableItem;
import main.symbolTable.items.FieldSymbolTableItem;
import main.symbolTable.items.LocalVariableSymbolTableItem;
import main.symbolTable.items.MethodSymbolTableItem;
import main.symbolTable.utils.graph.Graph;
import main.visitor.Visitor;
import main.ast.nodes.Node;

import java.util.ArrayList;

public class ExpressionTypeChecker extends Visitor<Type> {
    private Graph<String> classHierarchy;
    private ClassDeclaration currClassDec;
    private MethodDeclaration currMethodDec;
    private boolean isInMethodCall = false;
    private boolean seenNoneLValue = false;
    private int typeValidationNumberOfErrors;

    public ExpressionTypeChecker(Graph<String> classHierarchy) {
        this.classHierarchy = classHierarchy;
    }

    public void setClassDec(ClassDeclaration classDec){
        this.currClassDec = classDec;
    }

    public void setMethodDec(MethodDeclaration methodDec){
        this.currMethodDec = methodDec;
    }

    public void checkClassDec(Node classDecNode, String className){
        if(!this.classHierarchy.doesGraphContainNode(className)){
            ClassNotDeclared classNotDeclaredException = new ClassNotDeclared(classDecNode.getLine(), className);
            classDecNode.addError(classNotDeclaredException);
            this.typeValidationNumberOfErrors += 1;
        }
    }

    public void checkArrayDec(Node arrayDec, Type type){
        for(Expression dimExp : ((ArrayType)type).getDimensions() ) {
            if(((IntValue) dimExp).getConstant() == 0) {
                CannotHaveEmptyArray cannotHaveEmptyArrayException = new CannotHaveEmptyArray(arrayDec.getLine());
                arrayDec.addError(cannotHaveEmptyArrayException);
                this.typeValidationNumberOfErrors += 1;
            }
        }
    }

    public void checkFptrDec(Node fptrDec, Type type){
        if(!(type instanceof ClassType || type instanceof FptrType || type instanceof ArrayType))
            return;
        if(type instanceof ArrayType){
            checkArrayDec(fptrDec, type);
        }
        if(type instanceof ClassType){
            String className = ((ClassType)type).getClassName().getName();
            checkClassDec(fptrDec, className);
        }
        if(type instanceof FptrType) {
            Type returnType = ((FptrType) type).getReturnType();
            ArrayList<Type> argsType = ((FptrType) type).getArgumentsTypes();
            this.checkFptrDec(fptrDec, returnType);
            for(Type argType : argsType)
                this.checkFptrDec(fptrDec, argType);
        }
    }

    public void setIsInMethodCallStmt(boolean isInMethodCall_){
        isInMethodCall = isInMethodCall_;
    }

    public boolean isFirstSubTypeOfSecondMultiple(ArrayList<Type> first, ArrayList<Type> second) {
        if(first.size() != second.size())
            return false;
        for(int i = 0; i < first.size(); i++) {
            if(!isFirstSubTypeOfSecond(first.get(i), second.get(i)))
                return false;
        }
        return true;
    }

    public boolean isFirstSubTypeOfSecond(Type first, Type second){
        if(first instanceof NoType)
            return true;
        else if(first instanceof IntType && second instanceof IntType)
            return true;
        else if(first instanceof BoolType && second instanceof BoolType)
            return true;
        else if(first instanceof NullType && (second instanceof NullType || second instanceof FptrType || second instanceof ClassType))
            return true;
        else if(first instanceof ClassType) {
            if(!(second instanceof ClassType))
                return false;
            return this.classHierarchy.isSecondNodeAncestorOf(((ClassType) first).getClassName().getName(), ((ClassType) second).getClassName().getName());
        }
        else if(first instanceof FptrType) {
            if(!(second instanceof FptrType))
                return false;
            Type firstRetType = ((FptrType) first).getReturnType();
            Type secondRetType = ((FptrType) second).getReturnType();
            if(!isFirstSubTypeOfSecond(firstRetType, secondRetType))
                return false;
            ArrayList<Type> firstArgsTypes = ((FptrType) first).getArgumentsTypes();
            ArrayList<Type> secondArgsTypes = ((FptrType) second).getArgumentsTypes();

            if(secondArgsTypes.size() != firstArgsTypes.size())
                return false;
            for(int i = 0; i < secondArgsTypes.size(); i++) {
                if(!isFirstSubTypeOfSecond(secondArgsTypes.get(i), firstArgsTypes.get(i)))
                    return false;
            }
            return true;
        }
        return false;
    }

    public Type refineType(Type type) {
        this.typeValidationNumberOfErrors = 0;

        if(type instanceof ArrayType)
            this.checkArrayDec(new NullValue(), type);
        if(type instanceof ClassType)
            this.checkClassDec(new NullValue(), ((ClassType) type).getClassName().getName());
        if(type instanceof FptrType)
            this.checkFptrDec(new NullValue(), type);

        if(this.typeValidationNumberOfErrors > 0)
            return new NoType();
        return type;
    }

    public boolean isLvalue(Expression expression) {
        boolean prevIsCatchErrorsActive = Node.isCatchErrorsActive;
        boolean prevSeenNoneLvalue = this.seenNoneLValue;
        Node.isCatchErrorsActive = false;
        this.seenNoneLValue = false;
        expression.accept(this);
        boolean isLvalue = !this.seenNoneLValue;
        this.seenNoneLValue = prevSeenNoneLvalue;
        Node.isCatchErrorsActive = prevIsCatchErrorsActive;
        return isLvalue;
    }

    @Override
    public Type visit(BinaryExpression binaryExpression) {
        //Todo
        // = , | , & , == , < , > , + , - , * , /

        this.seenNoneLValue = true;
        BinaryOperator binaryOperator = binaryExpression.getBinaryOperator();
        System.out.println(binaryOperator.name());
        Type leftType = binaryExpression.getFirstOperand().accept(this);
        Type rightType = binaryExpression.getSecondOperand().accept(this);
//        System.out.println("assign : " + binaryExpression.getLine() + "  "+ binaryOperator.name());
        if(binaryOperator != BinaryOperator.assign) {
            if (leftType instanceof NoType && rightType instanceof NoType)
                return new NoType();
        }
        if(binaryOperator == BinaryOperator.assign){
//            System.out.println("assign : " + leftType.toString() + rightType.toString());
            boolean isFirstLvalue = this.isLvalue(binaryExpression.getFirstOperand());
            if(!isFirstLvalue) {
                LeftSideNotLvalue exception = new LeftSideNotLvalue(binaryExpression.getLine());
                binaryExpression.addError(exception);
            }
            if(leftType instanceof NoType || rightType instanceof NoType) {
                return new NoType();
            }
            boolean isSubtype = this.isFirstSubTypeOfSecond(rightType, leftType);
            if(isSubtype) {
                if(isFirstLvalue)
                    return rightType;
                return new NoType();
            }
            UnsupportedOperandType exception = new UnsupportedOperandType(binaryExpression.getLine(), binaryOperator.name());
            binaryExpression.addError(exception);
            return new NoType();
        }

        if(binaryOperator == BinaryOperator.eq){
            if((leftType instanceof NoType && (rightType instanceof ArrayType || rightType instanceof SetType)) ||
               (rightType instanceof NoType && (leftType instanceof ArrayType || leftType instanceof SetType))){
                UnsupportedOperandType unsupportedOperandTypeException =
                        new UnsupportedOperandType(binaryExpression.getLine(), binaryOperator.name());
                binaryExpression.addError(unsupportedOperandTypeException);
                return new NoType();
            }
            else if(leftType instanceof NoType || rightType instanceof NoType)
                return new NoType();

            if(leftType instanceof IntType && rightType instanceof IntType)
                return new BoolType();
            if(leftType instanceof BoolType && rightType instanceof BoolType)
                return new BoolType();

            if(leftType instanceof ClassType && rightType instanceof ClassType) {
                String leftClassName = ((ClassType)leftType).getClassName().getName();
                String rightClassName = ((ClassType)rightType).getClassName().getName();
                if(leftClassName.equals(rightClassName))
                    return new BoolType();
            }
            if(leftType instanceof ClassType && rightType instanceof NullType)
                return new BoolType();
            if(leftType instanceof NullType && rightType instanceof ClassType)
                return new BoolType();
            if(leftType instanceof NullType && rightType instanceof NullType)
                return new BoolType();

            if(leftType instanceof FptrType && rightType instanceof FptrType)
                return new BoolType();
            if(leftType instanceof FptrType && rightType instanceof NullType)
                return new BoolType();
            if(leftType instanceof NullType && rightType instanceof FptrType)
                return new BoolType();
        }

        if(binaryOperator == BinaryOperator.gt || binaryOperator == BinaryOperator.lt){
            if(leftType instanceof IntType && rightType instanceof IntType)
                return new BoolType();

            if((leftType instanceof NoType && !(rightType instanceof IntType)) ||
                (rightType instanceof NoType && !(leftType instanceof IntType))){
                UnsupportedOperandType unsupportedOperandTypeException = new UnsupportedOperandType(binaryExpression.getLine(), binaryOperator.name());
                binaryExpression.addError(unsupportedOperandTypeException);
                return new NoType();
            }
            else if(leftType instanceof NoType || rightType instanceof NoType)
                return new NoType();
        }

        if((binaryOperator == BinaryOperator.add) || (binaryOperator == BinaryOperator.sub) ||
                (binaryOperator == BinaryOperator.mult) || (binaryOperator == BinaryOperator.div)) {
            if((leftType instanceof IntType) && (rightType instanceof IntType))
                return new IntType();

            if((leftType instanceof NoType && !(rightType instanceof IntType)) ||
                    (rightType instanceof NoType && !(leftType instanceof IntType))) {
                UnsupportedOperandType exception = new UnsupportedOperandType(binaryExpression.getLine(), binaryOperator.name());
                binaryExpression.addError(exception);
                return new NoType();
            }
            else if(leftType instanceof NoType || rightType instanceof NoType)
                return new NoType();
        }

        if((binaryOperator == BinaryOperator.or) || (binaryOperator == BinaryOperator.and)) {
            if((leftType instanceof BoolType) && (rightType instanceof BoolType))
                return new BoolType();

            if((leftType instanceof NoType && !(rightType instanceof BoolType)) ||
                    (rightType instanceof NoType && !(leftType instanceof BoolType))) {
                UnsupportedOperandType exception = new UnsupportedOperandType(binaryExpression.getLine(), binaryOperator.name());
                binaryExpression.addError(exception);
                return new NoType();
            }
            else if(leftType instanceof NoType || rightType instanceof NoType)
                return new NoType();
        }

        UnsupportedOperandType unsupportedOperandTypeException = new UnsupportedOperandType(binaryExpression.getLine(), binaryOperator.name());
        binaryExpression.addError(unsupportedOperandTypeException);
        return new NoType();
    }

    @Override
    public Type visit(NewClassInstance newClassInstance) {
        //todo
        this.seenNoneLValue = true;
        ArrayList <Type> argsTypes = new ArrayList<>();

        for(Expression expression : newClassInstance.getArgs()) {
            Type expressionType = expression.accept(this);
            argsTypes.add(expressionType);
        }

        String className = newClassInstance.getClassType().getClassName().getName();
        if(!(this.classHierarchy.doesGraphContainNode(className))){
            ClassNotDeclared classNotDeclaredException = new ClassNotDeclared(newClassInstance.getLine(), className);
            newClassInstance.addError(classNotDeclaredException);
            return new NoType();
        }
        try {
            ClassSymbolTableItem classSymbolTableItem = (ClassSymbolTableItem) SymbolTable.root.getItem(ClassSymbolTableItem.START_KEY + className, true);
            MethodSymbolTableItem methodSymbolTableItem = (MethodSymbolTableItem) classSymbolTableItem.getClassSymbolTable().getItem(MethodSymbolTableItem.START_KEY + "initialize", true);
            ArrayList<Type> constructorActualTypes = methodSymbolTableItem.getArgTypes();

            if(argsTypes.size() != constructorActualTypes.size()){
                ConstructorArgsNotMatchDefinition constructorArgsNotMatchDefinitionException = new ConstructorArgsNotMatchDefinition(newClassInstance);
                newClassInstance.addError(constructorArgsNotMatchDefinitionException);
                return new NoType();
            }
            for(int i = 0; i < argsTypes.size(); i++) {

                if(!isFirstSubTypeOfSecond(argsTypes.get(i), constructorActualTypes.get(i))){

                    ConstructorArgsNotMatchDefinition constructorArgsNotMatchDefinitionException = new ConstructorArgsNotMatchDefinition(newClassInstance);
                    newClassInstance.addError(constructorArgsNotMatchDefinitionException);
                    return new NoType();
                }
            }
            return newClassInstance.getClassType();

        } catch (ItemNotFoundException ignored){
            if(argsTypes.size() != 0) {
//                System.out.println("constructor : " + newClassInstance.getLine() + " ");
                ConstructorArgsNotMatchDefinition exception = new ConstructorArgsNotMatchDefinition(newClassInstance);
                newClassInstance.addError(exception);
                return new NoType();
            }
            else {
                return newClassInstance.getClassType();
            }
        }
    }

    @Override
    public Type visit(UnaryExpression unaryExpression) {
        //Todo
        this.seenNoneLValue = true;
        Type type = unaryExpression.getOperand().accept(this);
        UnaryOperator unaryOperator = unaryExpression.getOperator();

        if(type instanceof NoType)
            return new NoType();

        if(unaryOperator == UnaryOperator.not) {
            if(type instanceof BoolType)
                return type;
            UnsupportedOperandType UnsupportedOperandTypeException = new UnsupportedOperandType(unaryExpression.getLine(), unaryOperator.name());
            unaryExpression.addError(UnsupportedOperandTypeException);
            return new NoType();
        }
        if(unaryOperator == UnaryOperator.minus) {
            if(type instanceof IntType)
                return type;
            UnsupportedOperandType UnsupportedOperandTypeException = new UnsupportedOperandType(unaryExpression.getLine(), unaryOperator.name());
            unaryExpression.addError(UnsupportedOperandTypeException);
            return new NoType();
        }

        if(unaryOperator == UnaryOperator.postdec || unaryOperator == UnaryOperator.postinc){
//            System.out.println(unaryOperator);
            boolean isOperandLvalue = this.isLvalue(unaryExpression.getOperand());
//            System.out.println(isOperandLvalue);
            if(!isOperandLvalue) {
                IncDecOperandNotLvalue exception = new IncDecOperandNotLvalue(unaryExpression.getLine(), unaryOperator.name());
                unaryExpression.addError(exception);
            }
            if(type instanceof IntType) {
                if(isOperandLvalue)
                    return type;
                return new NoType();
            }
        }
        UnsupportedOperandType UnsupportedOperandTypeException = new UnsupportedOperandType(unaryExpression.getLine(), unaryOperator.name());
        unaryExpression.addError(UnsupportedOperandTypeException);
        return new NoType();
    }

    @Override
    public Type visit(MethodCall methodCall) {
        //Todo
        this.seenNoneLValue = true;
        Type instanceType = methodCall.getInstance().accept(this);
//        System.out.println(methodCall.getInstance());
        boolean prevIsInMethodCallStmt = this.isInMethodCall;
        this.setIsInMethodCallStmt(false);
        ArrayList<Type> argsTypes = new ArrayList<>();
        for(Expression arg : methodCall.getArgs()) {
            argsTypes.add(arg.accept(this));
        }
        this.setIsInMethodCallStmt(prevIsInMethodCallStmt);
        if(!(instanceType instanceof FptrType || instanceType instanceof NoType)) {
            CallOnNoneCallable exception = new CallOnNoneCallable(methodCall.getLine());
            methodCall.addError(exception);
            return new NoType();
        }
        else if(instanceType instanceof NoType) {
            return new NoType();
        }
        else {
            ArrayList<Type> actualArgsTypes = ((FptrType) instanceType).getArgumentsTypes();
            Type returnType = ((FptrType) instanceType).getReturnType();
            boolean hasError = false;
            if(!this.isInMethodCall && (returnType instanceof NullType)) {
                CantUseValueOfVoidMethod exception = new CantUseValueOfVoidMethod(methodCall.getLine());
                methodCall.addError(exception);
                hasError = true;
            }
            if(this.isFirstSubTypeOfSecondMultiple(argsTypes, actualArgsTypes)) {
                if(hasError)
                    return new NoType();
                return this.refineType(returnType);
            }
            else {
                MethodCallNotMatchDefinition exception = new MethodCallNotMatchDefinition(methodCall.getLine());
                methodCall.addError(exception);
                return new NoType();
            }
        }
    }

    @Override
    public Type visit(Identifier identifier) {
        //Todo
        try {
            ClassSymbolTableItem classSymbolTableItem = (ClassSymbolTableItem) SymbolTable.root.getItem(ClassSymbolTableItem.START_KEY + this.currClassDec.getClassName().getName(), true);
            SymbolTable classSymbolTable = classSymbolTableItem.getClassSymbolTable();
            MethodSymbolTableItem methodSymbolTableItem = (MethodSymbolTableItem) classSymbolTable.getItem(MethodSymbolTableItem.START_KEY + this.currMethodDec.getMethodName().getName(), true);
            SymbolTable methodSymbolTable = methodSymbolTableItem.getMethodSymbolTable();
            LocalVariableSymbolTableItem localVariableSymbolTableItem = (LocalVariableSymbolTableItem) methodSymbolTable.getItem(LocalVariableSymbolTableItem.START_KEY + identifier.getName(), true);

            this.typeValidationNumberOfErrors = 0;
            Type varType = localVariableSymbolTableItem.getType();
            if(varType instanceof ArrayType)
                this.checkArrayDec(new NullValue(), varType);
            if(varType instanceof ClassType)
                this.checkClassDec(new NullValue(), ((ClassType) varType).getClassName().getName());
            if(varType instanceof FptrType)
                this.checkFptrDec(new NullValue(), varType);

            if(this.typeValidationNumberOfErrors > 0)
                return new NoType();
//            System.out.println("id : " + identifier.getLine() + " " + identifier.getName() + " " + varType.toString());
            return varType;
        } catch (ItemNotFoundException e) {
            VarNotDeclared exception = new VarNotDeclared(identifier.getLine(), identifier.getName());
            identifier.addError(exception);
            return new NoType();
        }
    }

    @Override
    public Type visit(ArrayAccessByIndex arrayAccessByIndex) {
        //Todo
        Type instanceType = arrayAccessByIndex.getInstance().accept(this);
        boolean prevSeenNoneLvalue = this.seenNoneLValue;
        Type indexType = arrayAccessByIndex.getIndex().accept(this);
        this.seenNoneLValue = prevSeenNoneLvalue;
        if(!(indexType instanceof NoType) && !(indexType instanceof IntType)) {
            ArrayIndexNotInt exception = new ArrayIndexNotInt(arrayAccessByIndex.getLine());
            arrayAccessByIndex.addError(exception);
            return new NoType();
        }
        if(instanceType instanceof ArrayType && indexType instanceof IntType){
            return ((ArrayType) instanceType).getType();
        }
        else if(!(instanceType instanceof NoType)) {
            AccessByIndexOnNoneArray exception = new AccessByIndexOnNoneArray(arrayAccessByIndex.getLine());
            arrayAccessByIndex.addError(exception);
        }
        return new NoType();
    }

    @Override
    public Type visit(ObjectMemberAccess objectMemberAccess) {
        //Todo
        boolean prevSeenNoneLvalue = this.seenNoneLValue;
        Type instanceType = objectMemberAccess.getInstance().accept(this);
        if(objectMemberAccess.getInstance() instanceof SelfClass)
            this.seenNoneLValue = prevSeenNoneLvalue;
        String memberName = objectMemberAccess.getMemberName().getName();
        if(instanceType instanceof NoType)
            return new NoType();
        else if(instanceType instanceof ClassType) {
            String className = ((ClassType) instanceType).getClassName().getName();
            SymbolTable classSymbolTable;
            try {
                classSymbolTable = ((ClassSymbolTableItem) SymbolTable.root.getItem(ClassSymbolTableItem.START_KEY + className, true)).getClassSymbolTable();
            } catch (ItemNotFoundException classNotFound) {
                return new NoType();
            }
            try {
                FieldSymbolTableItem fieldSymbolTableItem = (FieldSymbolTableItem) classSymbolTable.getItem(FieldSymbolTableItem.START_KEY + memberName, true);
                return this.refineType(fieldSymbolTableItem.getType());
            } catch (ItemNotFoundException memberNotField) {
                try {
                    MethodSymbolTableItem methodSymbolTableItem = (MethodSymbolTableItem) classSymbolTable.getItem(MethodSymbolTableItem.START_KEY + memberName, true);
                    this.seenNoneLValue = true;
                    return new FptrType(methodSymbolTableItem.getArgTypes(), methodSymbolTableItem.getReturnType());
                } catch (ItemNotFoundException memberNotFound) {
                    if(memberName.equals(className)) {
                        this.seenNoneLValue = true;
                        return new FptrType(new ArrayList<>(), new NullType());
                    }
                    MemberNotAvailableInClass exception = new MemberNotAvailableInClass(objectMemberAccess.getLine(), memberName, className);
                    objectMemberAccess.addError(exception);
                    return new NoType();
                }
            }
        }
        else {
            AccessOnNonClass exception = new AccessOnNonClass(objectMemberAccess.getLine());
            objectMemberAccess.addError(exception);
            return new NoType();
        }
    }

    @Override
    public Type visit(SetNew setNew) {
        //Todo
        for(Expression expression : setNew.getArgs()){
            Type type = expression.accept(this);
            if(!(type instanceof IntType) && !(type instanceof NoType)){
                NewInputNotSet newInputNotSetException = new NewInputNotSet(setNew.getLine());
                setNew.addError(newInputNotSetException);
            }
        }
        return new NoType();
    }

    @Override
    public Type visit(SetInclude setInclude) {
        //Todo
        Type type = setInclude.getElementArg().accept(this);
        if(!(type instanceof IntType)){
            SetIncludeInputNotInt setIncludeInputNotIntException = new SetIncludeInputNotInt(setInclude.getLine());
            setInclude.addError(setIncludeInputNotIntException);
        }
        return new NoType();
    }

    @Override
    public Type visit(RangeExpression rangeExpression) {
        //Todo
//        System.out.println("range");
        Type leftExprType = rangeExpression.getLeftExpression().accept(this);
        Type rightExprType = rangeExpression.getRightExpression().accept(this);
        if(leftExprType instanceof NoType || rightExprType instanceof NoType)
            return new NoType();
        if(!(leftExprType instanceof IntType) || !(rightExprType instanceof IntType)){
            EachRangeNotInt eachRangeNotIntException = new EachRangeNotInt(rangeExpression.getLine());
            rangeExpression.addError(eachRangeNotIntException);
            return new NoType();
        }
        else
            return new IntType(); ////////////////////////////////////////////////////
    }

    @Override
    public Type visit(TernaryExpression ternaryExpression) {
        //Todo
        Type conditionOperandType = ternaryExpression.getCondition().accept(this);
        if(!(conditionOperandType instanceof BoolType) && !(conditionOperandType instanceof NoType)){
            ConditionNotBool conditionNotBoolException = new ConditionNotBool(ternaryExpression.getLine());
            ternaryExpression.addError(conditionNotBoolException);
            return new NoType();
        }

        Type trueOperandType = ternaryExpression.getTrueExpression().accept(this);
        Type falseOperandType = ternaryExpression.getFalseExpression().accept(this);

        if(trueOperandType instanceof NoType || falseOperandType instanceof NoType)
            return new NoType();
        if(!(trueOperandType.toString().equals(falseOperandType.toString()))){
            UnsupportedOperandType unsupportedOperandTypeException = new UnsupportedOperandType(ternaryExpression.getLine(), TernaryOperator.ternary.name());
            ternaryExpression.addError(unsupportedOperandTypeException);
            return new NoType();
        }
        else {
            return trueOperandType;
        }
    }

    @Override
    public Type visit(IntValue intValue) {
        //Todo
        this.seenNoneLValue = true;
        return new IntType();
    }

    @Override
    public Type visit(BoolValue boolValue) {
        //Todo
        this.seenNoneLValue = true;
        return new BoolType();
    }

    @Override
    public Type visit(SelfClass selfClass) {
        //todo
        this.seenNoneLValue = true;
        return new ClassType(this.currClassDec.getClassName());
    }

    @Override
    public Type visit(SetValue setValue) {
        //todo
        this.seenNoneLValue = true;
        return new SetType();
    }

    @Override
    public Type visit(NullValue nullValue) {
        //todo
        this.seenNoneLValue = true;
        return new NullType();
    }
}
